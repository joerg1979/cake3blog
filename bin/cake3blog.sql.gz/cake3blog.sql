-- phpMyAdmin SQL Dump
-- version 4.3.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Erstellungszeit: 13. Feb 2015 um 21:28
-- Server-Version: 5.6.20
-- PHP-Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `cake3blog`
--
CREATE DATABASE IF NOT EXISTS `cake3blog` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `cake3blog`;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `articles`
--

DROP TABLE IF EXISTS `articles`;
CREATE TABLE IF NOT EXISTS `articles` (
  `id` int(10) unsigned NOT NULL,
  `title` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `body` text COLLATE utf8_bin,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- TRUNCATE Tabelle vor dem Einfügen `articles`
--

TRUNCATE TABLE `articles`;
--
-- Daten für Tabelle `articles`
--

INSERT INTO `articles` (`id`, `title`, `body`, `created`, `modified`) VALUES
(1, 'ArticlesController - action - add()', 'public function add() {\r\n        $article = $this->Articles->newEntity($this->request->data);\r\n        if($this->request->is(''post'')){\r\n            if($this->Articles->save($article)) {\r\n                $this->Flash->success(__(''Your article has been saved.''));\r\n                return $this->redirect([''action'' => ''index'']);\r\n            }\r\n            $this->Flash->error(__(''Unable to add your article!''));\r\n        }\r\n        $this->set(''article'', $article);\r\n    }', '2015-02-13 19:34:01', '2015-02-13 19:34:01'),
(2, ' 	ArticlesController - action - edit($id)', '    public function edit($id = NULL){\r\n        if(!$id){\r\n            throw new NotFoundException(__(''Invalid article''));\r\n        }\r\n        \r\n        $article = $this->Articles->get($id);\r\n        \r\n        if($this->request->is([''post'', ''put''])){\r\n            $this->Articles->patchEntity($article, $this->request->data);\r\n            if($this->Articles->save($article)){\r\n                $this->Flash->success(__(''Your article has been updated.''));\r\n                return $this->redirect([''action'' => ''index'']);\r\n            }\r\n            $this->Flash->error(__(''Unabke to update your article.''));\r\n        }\r\n        $this->set(''article'', $article);\r\n    }', '2015-02-13 19:58:57', '2015-02-13 20:11:23'),
(3, 'ArticlesController - action - delete($id)', 'public function delete($id){\r\n        $this->request->allowMethod([''post'', ''delete'']);\r\n        \r\n        if(!$id){\r\n            throw new NotFoundException(__(''Invalid article''));\r\n        }\r\n        \r\n        $article = $this->Articles->get($id);\r\n        if($this->Articles->delete($article)){\r\n            $this->Flash->success(__(''The article with ID:{0} has been deleted'', \r\n                              h($id)));\r\n         return $this->redirect([''action'' => ''index'']);\r\n        }\r\n        \r\n    }', '2015-02-13 20:00:08', '2015-02-13 20:11:11'),
(4, 'ArticlesController - action - view($id)', 'public function view($id = null){\r\n        if (!$id){\r\n            throw new NotFoundException(__(''Ivalid atricle''));\r\n        }\r\n        $article = $this->Articles->get($id);\r\n        $this->set(compact(''article''));\r\n    }', '2015-02-13 20:01:42', '2015-02-13 20:01:42'),
(5, ' 	ArticlesController - action - index()', 'public function index() {\r\n        $articles = $this->Articles->find(''all'');\r\n        $this->set(compact(''articles''));\r\n    }', '2015-02-13 20:02:49', '2015-02-13 20:02:49'),
(6, 'ArticlesController - class', 'namespace App\\Controller;\r\n\r\nuse Cake\\Network\\Exception\\NotFoundException;\r\n\r\nclass ArticlesController extends AppController {\r\n\r\n}', '2015-02-13 20:09:57', '2015-02-13 20:10:32'),
(7, 'ArticlesTable - Modell\\Table', 'namespace App\\Model\\Table;\r\n\r\nuse Cake\\ORM\\Table;\r\nuse Cake\\Validation\\Validator;\r\n\r\nclass ArticlesTable extends Table {\r\n    public function initialize(array $config) {\r\n        $this->addBehavior(''Timestamp'');\r\n    }    \r\n    public function valdationDefault(Validator $validator) {\r\n        $validator->notEmpty(''title'')->notEmpty(''body'');\r\n        return $validator;\r\n    }    \r\n}', '2015-02-13 20:15:42', '2015-02-13 20:15:42'),
(8, 'Articles - view - index.ctp', '<h1>Blog articles</h1>\r\n<p><?= $this->Html->link(''Add article'', [''action''=>''add'']) ?></p>\r\n<table>\r\n    <tr>\r\n        <th>ID</th>\r\n        <th>Title</th>\r\n        <th>Created</th>\r\n        <th>Action</th>\r\n    </tr>\r\n    <?php foreach($articles as $article): ?>\r\n    <tr>\r\n        <td><?= $article->id ?></td>\r\n        <td><?= $this->Html->link($article->title,[''action'' => ''view'', $article->id]) ?>\r\n        </td>\r\n        <td><?= $article->created->format(DATE_RFC850) ?></td>\r\n        <td>\r\n            <?= $this->Form->postLink(\r\n                    ''Delete'',\r\n                    [''action'' => ''delete'', $article->id],\r\n                    [''confirm'' => ''Delete article ID:'' . $article->id.'' Are you sure?'']) ?>\r\n            <?= $this->Html->link(''Edit'', [''action'' => ''edit'', $article->id]) ?></td>\r\n    </tr>\r\n    <?php endforeach; ?>\r\n</table>', '2015-02-13 20:22:16', '2015-02-13 20:22:16'),
(9, 'Articles - view - view.ctp', '<h1><?= h($article->title) ?></h1>\r\n<p><?= $this->Html->link(''edit article'', [''action''=>''edit'', h($article->id)]) ?></p>\r\n<pre><?= h($article->body) ?></pre>  \r\n<small>Created: <?= $article->created ?></small>', '2015-02-13 20:22:38', '2015-02-13 20:22:38'),
(10, 'Articles - view - add.ctp', '<h1>Add article</h1>\r\n<?php \r\n    echo $this->Form->create($article);\r\n    echo $this->Form->input(''title'');\r\n    echo $this->Form->input(''body'', [''rows'' => ''15'']);\r\n    echo $this->Form->button(__(''Save article''));\r\n    echo $this->Form->end();        \r\n?>', '2015-02-13 20:23:09', '2015-02-13 20:23:09'),
(11, 'Articles - view - edit.ctp', '<h1>Edit article ID: <?= $article->id ?></h1>\r\n    <?php \r\n    echo $this->Form->create($article);\r\n    echo $this->Form->input(''title'');\r\n    echo $this->Form->input(''body'', [''rows'' => ''15'']);\r\n    echo $this->Form->button(__(''Save article''));\r\n    echo $this->Form->end();\r\n?>', '2015-02-13 20:24:00', '2015-02-13 20:24:00');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL,
  `username` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `role` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- TRUNCATE Tabelle vor dem Einfügen `users`
--

TRUNCATE TABLE `users`;
--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT für Tabelle `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
